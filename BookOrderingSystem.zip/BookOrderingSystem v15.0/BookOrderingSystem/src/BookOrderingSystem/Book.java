package BookOrderingSystem;

public interface Book {
    
    double getPrice();
    String getDesc();
}
